//RELOAD IFRAME

function reloadIframe(element) {
   var iframe = document.getElementById(element);
   iframe.src = iframe.src;
}